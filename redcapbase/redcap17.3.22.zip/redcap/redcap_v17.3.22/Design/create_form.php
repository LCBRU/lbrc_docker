<?php

use Vanderbilt\REDCap\Classes\ProjectDesigner;

require_once dirname(dirname(__FILE__)) . '/Config/init_project.php';

// A submitted production revision must remain unchanged while awaiting approval.
if ($status > 0 && (int)$draft_mode !== 1) exit('0');

$projectDesigner = new ProjectDesigner($Proj);
$created = $projectDesigner->createForm($_POST['form_name'], $_POST['after_form']);
if(!$created) exit('0');
print '1';
