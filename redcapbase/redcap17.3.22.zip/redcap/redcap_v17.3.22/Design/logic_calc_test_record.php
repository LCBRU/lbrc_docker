<?php

require_once dirname(dirname(__FILE__)) . "/Config/init_project.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !is_string($_POST['logic'] ?? null)
    || !is_string($_POST['record'] ?? null) || $_POST['record'] === '') {
    http_response_code(403);
    exit('');
}

$logic = $_POST['logic'];

// Obtain array of error fields that are not real fields
$error_fields = Design::validateBranchingCalc($logic);

// The Designer's record selector sends an unsuffixed ID for Double Data Entry.
$record = $_POST['record'];
$event_id = null;
// If receiving record-event_id, then split it up to prepend variables in the logic with unique events names (to apply it to a specific event)
if ($longitudinal && isset($_POST['hasrecordevent']) && $_POST['hasrecordevent'] == '1') {
	// Split record-event_id
	$posLastDash = strrpos($_POST['record'], '-');
	$record = substr($_POST['record'], 0, $posLastDash);
	$event_id = substr($_POST['record'], $posLastDash+1);
	if ($record === '' || !isinteger($event_id) || !$Proj->validateEventId($event_id)) {
		http_response_code(403);
		exit('');
	}
	$event_id = (int)$event_id;
}
if ($double_data_entry && !empty($user_rights['double_data'])) $record .= '--' . $user_rights['double_data'];
if (!Records::recordExists(PROJECT_ID, $record) || !Records::recordBelongsToUsersDAG(PROJECT_ID, $record)) {
	http_response_code(403);
	exit('');
}
if ($event_id !== null) {
	$logic = Piping::pipeSpecialTags($logic, $project_id, $record, $event_id, 1, USERID, true, null, null, false, false, false, true);
	if (trim($logic) != '') {
		$logic = LogicTester::logicPrependEventName($logic, $Proj->getUniqueEventNames($event_id), $Proj);
	}
}

if (empty($error_fields))
{
	// Format calculation to PHP format
	$logic = LogicTester::formatLogicToPHP($logic, $Proj);
	// Get resulting calculation
	$val = LogicTester::evaluateLogicSingleRecord($logic, $record, null, null, 1, null, true);
	if ($val === "" || (is_float($val) && is_nan($val)) || !is_numeric($val))
		echo "[".$lang['design_708']."]";
	else
		echo $val;
}
else
{
	echo "[".$lang['design_708']."]";
}
