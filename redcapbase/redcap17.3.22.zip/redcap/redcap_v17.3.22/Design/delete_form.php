<?php

use Vanderbilt\REDCap\Classes\ProjectDesigner;

require_once dirname(dirname(__FILE__)) . '/Config/init_project.php';

// A submitted production revision must remain unchanged while awaiting approval.
if ($status > 0 && (int)$draft_mode !== 1) exit('0');

$projectDesigner = new ProjectDesigner($Proj);
$deleted = $projectDesigner->deleteForm($_POST['form_name']);
if(!$deleted) {
	// One or more fields are on this form, so return error code
	exit("3");
}
// Send successful response (1 = OK)
print "1";
