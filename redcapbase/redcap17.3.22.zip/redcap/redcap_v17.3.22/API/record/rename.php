<?php
global $format, $returnFormat, $post;

$renameProject = new Project(PROJECT_ID);
if ($renameProject->project['double_data_entry']) {
    $renameRights = UserRights::getPrivileges(PROJECT_ID, USERID);
    $entryPerson = $renameRights[PROJECT_ID][strtolower(USERID)]['double_data'] ?? '0';
    if ($entryPerson != '0') {
        $entrySuffix = '--'.$entryPerson;
        foreach (array($post['record'], $post['new_record_name']) as $recordName) {
            if (!is_scalar($recordName) || substr((string)$recordName, -strlen($entrySuffix)) !== $entrySuffix) {
                exit(RestUtility::sendResponse(403, 'The API request cannot rename a record outside your Double Data Entry partition.'));
            }
        }
    }
}

if (isinteger($post['dataAccessGroupId'])
    && Records::getRecordGroupId(PROJECT_ID, $post['record']) != $post['dataAccessGroupId']) {
    RestUtility::sendResponse(403, 'The API request cannot rename a record outside your Data Access Group.');
}

$content = REDCap::renameRecord(PROJECT_ID, $post['record'], $post['new_record_name'], $post['arm']??null);

# Logging
Logging::logEvent("", "redcap_data", "UPDATE", $post['new_record_name'],
                "old_record = '{$post['record']}',\nnew_record = '{$post['new_record_name']}'".(isset($post['arm']) ? ",\narm=".$post['arm'] : ""),
                "Rename Record (API$playground)");

# Send the response to the requestor
RestUtility::sendResponse(200, $content, $format);
