<?php
global $format, $returnFormat, $post;

$Proj = new Project(PROJECT_ID);
$user_rights = UserRights::getPrivileges(PROJECT_ID, USERID);
$user_rights = $user_rights[PROJECT_ID][strtolower(USERID)];
$ur = new UserRights();
$user_rights = $ur->setFormLevelPrivileges($user_rights);

# Get REDCap XML file/string
$post['returnMetadataOnly'] = (isset($post['returnMetadataOnly']) && ($post['returnMetadataOnly'] == '1' || strtolower($post['returnMetadataOnly']."") === 'true'));
$post['exportDataAccessGroups'] = (isset($post['exportDataAccessGroups']) && ($post['exportDataAccessGroups'] == '1' || strtolower($post['exportDataAccessGroups']."") === 'true'));
$post['exportSurveyFields'] = (isset($post['exportSurveyFields']) && ($post['exportSurveyFields'] == '1' || strtolower($post['exportSurveyFields']."") === 'true'));
$post['exportFiles'] = (isset($post['exportFiles']) && ($post['exportFiles'] == '1' || strtolower($post['exportFiles']."") === 'true'));
if (!$post['returnMetadataOnly'] && $Proj->project['double_data_entry'] && !empty($user_rights['double_data'])) {
	exit(RestUtility::sendResponse(403, 'Project XML data exports are not available to Double Data Entry users.'));
}
// Exporting project XML with data should require full data export rights.
if (!$post['returnMetadataOnly'] && ($user_rights['data_export_tool'] ?? '0') !== '1') {
	exit(RestUtility::sendResponse(403, 'You do not have full data export privileges'));
}
if (!$post['returnMetadataOnly']) {
	// The ODM data path does not apply per-form export rights itself. Check every
	// requested field, or every project field when no field subset was supplied.
	$fieldsToExport = empty($post['fields']) ? array_keys($Proj->metadata) : (array)$post['fields'];
	foreach ($fieldsToExport as $field) {
		if (!is_string($field) || !isset($Proj->metadata[$field])) {
			exit(RestUtility::sendResponse(400, 'Invalid field requested for project XML export'));
		}
		$form = $Proj->metadata[$field]['form_name'];
		if (($user_rights['forms_export'][$form] ?? '0') != '1') {
			exit(RestUtility::sendResponse(403, 'You do not have full data export privileges for the requested fields'));
		}
	}
	// ODM identifies each record even when its ID field was not selected.
	if ($Proj->table_pk_phi && ($user_rights['forms_export'][$Proj->firstForm] ?? '0') != '1') {
		exit(RestUtility::sendResponse(403, 'You do not have full data export privileges for record identifiers'));
	}
	// Survey identifiers and timestamps are assembled from every survey when
	// requested, independently of the selected data fields.
	if ($post['exportSurveyFields']) {
		foreach ($Proj->surveys as $survey) {
			if (($user_rights['forms_export'][$survey['form_name']] ?? '0') != '1') {
				exit(RestUtility::sendResponse(403, 'You do not have full data export privileges for survey fields'));
			}
		}
	}
}
if (isset($post['metadata_options'])) {
	$exportAllMetadataOptions = false;
} else {
	$exportAllMetadataOptions = true;
	$post['metadata_options'] = "";
}
$content = Project::getProjectXML($post['returnMetadataOnly'], $post['records'], $post['fields'], $post['events'], $user_rights['group_id'],
								  $post['exportDataAccessGroups'], $post['exportSurveyFields'], $post['filterLogic'], $post['exportFiles'], $exportAllMetadataOptions,
								  $post['metadata_options'], ProjectMigration::isApiMigrationRequest());

# Logging
$pmtlog = ProjectMigration::isApiMigrationRequest() ? "Initiating migration via Project Migration Tool to the REDCap instance {$post['pmt-instance-url']} (Instance ID {$post['pmt-instance-id']})" : "project_id = " . PROJECT_ID;
Logging::logEvent("", "redcap_projects", "MANAGE", PROJECT_ID, $pmtlog, "Export project XML (API$playground)");

# Send the response to the requestor
RestUtility::sendResponse(200, $content, $format);
