<?php

use Vanderbilt\REDCap\Classes\MyCap\Api\DB\ParticipantDB;
use Vanderbilt\REDCap\Classes\MyCap\Api\Handler\Error\ParticipantHandlerError;
use Vanderbilt\REDCap\Classes\MyCap\Api\Response;
use Vanderbilt\REDCap\Classes\MyCap\MyCapApi;
use Vanderbilt\REDCap\Classes\MyCap\MyCapConfiguration;

global $format, $post;
defined('NOAUTH') or define('NOAUTH', true);
$returnFormat = 'json';

$mc = new MyCapConfiguration();
$hmacKey = MyCapConfiguration::$hMacKey;

// Self-test requests (from MyCapConfiguration's API test harness) that have no participant
// context (e.g. Missing Expiration, Expired, Missing/Invalid Action) are signed with a key
// generated in a separate PHP process (the config-check page), so it can't be recovered via
// the static MyCapConfiguration::$hMacKey above. That key is transmitted alongside the request
// (in the clear) via the "hmac_key" field, and is only used below as a fallback signing key.
//
// This fallback is safe even though it's technically attacker-controllable: every real action
// that could reach the signature check below (i.e. anything other than the 4 ProjectHandler
// actions that intentionally bypass signature validation entirely in
// MyCapApi::validateRequest() when "par_code" is absent - see there for details) still
// independently requires a real "par_code" (and usually "stu_code") to be validated against
// the database inside its own handler before touching any project/participant data. So forging
// a signature here can, at most, satisfy this generic gate - it can never substitute for a real
// participant/study lookup.
//
// The "!isset($post['par_code'])" check below is not strictly required for safety (the
// par_code block further down always either overwrites $hmacKey with the real participant key
// or halts the script via Response::sendError()/exit before $hmacKey is ever used), but it's
// kept explicit so this fallback's safety doesn't depend on reasoning about execution order.
if (!isset($post['par_code']) && isset($post['hmac_key']) && trim((string)$post['hmac_key']) !== '') {
    $hmacKey = $post['hmac_key'];
}
if (isset($post['par_code'])) {
    try {
        // Load Participant
        $participant = new ParticipantDB();
        $participants = $participant->loadByCode($post['par_code']);
        $hmacKey = $participants['hmac_key']; // Participant-level hmac key
    } catch (Exception $e) {
		Response::sendError(
			400,
			ParticipantHandlerError::CODE_NOT_FOUND,
			$e->getMessage()
		);
    }
}
unset($post['content'], $post['hmac_key']);
// error_log("---- post array in mycap/display.php ----");
// error_log(print_r($post, true));
$myCapApi = new MyCapApi(array('hmacKey' => $hmacKey));
$myCapApi->processRequest($post);