<?php

// These examples use the tokens configured below. A deployed web server may
// serve this directory, so never let an HTTP request run an example script.
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit;
}

$GLOBALS['super_api_token'] = 'ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234ABCD1234';
$GLOBALS['api_token']       = '12340DCA87C567B6FAAC8147AD7E4790';
$GLOBALS['api_url']         = 'http://example.com/redcap/api/';
