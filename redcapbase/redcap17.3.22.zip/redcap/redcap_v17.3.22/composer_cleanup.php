<?php

// Run only after Composer has finished installing packages, never during extraction.
if (PHP_SAPI !== 'cli') {
    exit(1);
}

require_once __DIR__ . '/ca_bundle_cleanup.php';
echo 'Removed ', removeDistrustedBundledCertificates(__DIR__), ' distrusted bundled certificates.', PHP_EOL;

$manifest = json_decode(file_get_contents(getenv('COMPOSER') ?: 'composer.json'), true);
$vendorDir = getenv('COMPOSER_VENDOR_DIR') ?: ($manifest['config']['vendor-dir'] ?? 'vendor');
$composerDir = $vendorDir . '/composer';
if (!is_dir($composerDir) || is_link($composerDir)) {
    exit(0);
}

function removeComposerTemporaryPath($path)
{
    if (is_dir($path) && !is_link($path)) {
        foreach (new FilesystemIterator($path, FilesystemIterator::SKIP_DOTS) as $entry) {
            removeComposerTemporaryPath($entry->getPathname());
        }
        $remove = 'rmdir';
    } else {
        $remove = 'unlink';
    }

    // Windows scanners can briefly hold newly extracted files open.
    for ($attempt = 0; $attempt < 5; $attempt++) {
        if (@$remove($path)) {
            return;
        }
        usleep(200000);
    }
    throw new RuntimeException('Could not remove Composer temporary path: ' . $path);
}

$removed = 0;
foreach (new FilesystemIterator($composerDir, FilesystemIterator::SKIP_DOTS) as $entry) {
    $name = $entry->getFilename();
    $temporaryArchive = !$entry->isDir() && preg_match('/^tmp-[a-f0-9]{32}(?:\.zip)?$/i', $name);
    $temporaryExtraction = $entry->isDir() && preg_match('/^[a-f0-9]{8}$/i', $name);
    if ($temporaryArchive || $temporaryExtraction) {
        removeComposerTemporaryPath($entry->getPathname());
        $removed++;
    }
}

echo 'Removed ', $removed, ' Composer temporary archives/directories.', PHP_EOL;

