<?php


// Check if coming from survey or authenticated form
if (isset($_GET['s']) && !empty($_GET['s']))
{
	// Call config_functions before config file in this case since we need some setup before calling config
	require_once dirname(dirname(__FILE__)) . '/Config/init_functions.php';
	// Validate and clean the survey hash, while also returning if a legacy hash
	$hash = $_GET['s'] = Survey::checkSurveyHash();
	// Set all survey attributes as global variables
	Survey::setSurveyVals($hash);
	// Now set $_GET['pid'] before calling config
	$_GET['pid'] = $project_id;
	// Set flag for no authentication for survey pages
	defined("NOAUTH") or define("NOAUTH", true);
}

require_once dirname(dirname(__FILE__)) . '/Config/init_project.php';

// The chart is converted to a PNG and downloaded by the browser. This route
// receives only a small logging request and never processes client image bytes.
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('ERROR!');
}
$fieldName = $_GET['field'] ?? null;
$field = is_string($fieldName) ? ($Proj->metadata[$fieldName] ?? null) : null;
$formName = $field['form_name'] ?? null;
$canLog = false;
if (defined('NOAUTH')) {
    $resultsCode = $_GET['__results'] ?? null;
    $resultsCodeHash = $_POST['results_code_hash'] ?? null;
    $canLog = $surveys_enabled && $survey_enabled > 0 && $date_deleted == '' && $status != 2
        && $completed_time == '' && ($survey_expiration == '' || $survey_expiration > NOW)
        && !Survey::privateSurveyLinkExpired($participant_email, $participant_id, $survey_time_limit_days, $survey_time_limit_hours, $survey_time_limit_minutes)
        && $enable_plotting_survey_results && in_array((string)$view_results, ['1', '3'], true)
        && is_string($resultsCode) && is_string($resultsCodeHash)
        && DataExport::verifySurveyResultsCode($hash, $resultsCode, $resultsCodeHash)
        && in_array($fieldName, DataExport::getFieldsToChart(PROJECT_ID, $form_name), true);
    if ($canLog) {
        $q = db_query('select 1 from redcap_surveys_participants p '
            . 'join redcap_surveys_response r on r.participant_id = p.participant_id '
            . 'where p.hash = ? and p.survey_id = ? and p.event_id = ? '
            . 'and r.results_code = ? and r.completion_time is not null limit 1',
            [$hash, $survey_id, $event_id, trim($resultsCode)]);
        $canLog = $q && db_num_rows($q) > 0;
    }
    if ($canLog) {
        $q = db_query('select count(distinct r.record) from redcap_surveys_participants p '
            . 'join redcap_surveys_response r on r.participant_id = p.participant_id '
            . 'where p.survey_id = ? and p.event_id = ? '
            . 'and r.completion_time is not null and r.first_submit_time is not null',
            [$survey_id, $event_id]);
        $canLog = $q && db_result($q, 0) >= $min_responses_view_results;
    }
} else {
    $canLog = $formName !== null && isset($user_rights['forms'][$formName])
        && !UserRights::hasDataViewingRights($user_rights['forms'][$formName], 'no-access');
}
if (!$canLog) {
    http_response_code(403);
    exit('ERROR!');
}

Logging::logEvent('', 'redcap_data', 'manage', $fieldName,
    "field_name = '".db_escape($fieldName)."'", 'Download graphical chart for field');
http_response_code(204);
