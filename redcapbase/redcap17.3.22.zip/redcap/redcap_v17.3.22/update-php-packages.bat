@echo off
setlocal
rem Prefer native archive extraction for large packages such as google/apiclient-services.
where 7z >nul 2>&1
if errorlevel 1 (
	if exist "%ProgramFiles%\7-Zip\7z.exe" set "PATH=%ProgramFiles%\7-Zip;%PATH%"
)

pushd "%~dp0" || exit /b 1
call composer update --no-dev
if errorlevel 1 goto failed
call composer --working-dir=Libraries update --no-dev
if errorlevel 1 goto failed
call composer --working-dir=UnitTests update
if errorlevel 1 goto failed
popd
echo SUCCESS: All PHP dependencies have been updated!
exit /b 0

:failed
set "UPDATE_EXIT_CODE=%ERRORLEVEL%"
popd
echo ERROR: PHP dependency update failed.
exit /b %UPDATE_EXIT_CODE%