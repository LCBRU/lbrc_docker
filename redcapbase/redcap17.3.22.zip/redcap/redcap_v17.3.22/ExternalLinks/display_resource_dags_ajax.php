<?php



// Config
require_once dirname(dirname(__FILE__)) . '/Config/init_project.php';

// Default response
$response = '0';

// Validate the request
if (isset($_POST['ext_id']) && isinteger($_POST['ext_id']))
{
	if ((int)$_POST['ext_id'] < 0) exit($response);
	if ((int)$_POST['ext_id'] > 0) {
		$q = db_query('select 1 from redcap_external_links where ext_id = ? and project_id = ? limit 1',
			[$_POST['ext_id'], PROJECT_ID]);
		if (!$q || !db_num_rows($q)) exit($response);
	}
	// Get this link resource
	$resource = $ExtRes->getResource($_POST['ext_id']);
	// Validate resource
	if ($resource !== false || $_POST['ext_id'] == '0')
	{
		// If user_access = ALL, then set all users as pre-checked
		if ((isset($resource['user_access']) && $resource['user_access'] == 'ALL') || $_POST['ext_id'] == '0')
		{
			$dags = 'ALL';
		}
		// Get list of user in the external users table
		else
		{
			$sql = "select group_id from redcap_external_links_dags where ext_id = " . $_POST['ext_id'];
			$q = db_query($sql);
			$dags = array();
			while ($row = db_fetch_assoc($q))
			{
				$dags[] = $row['group_id'];
			}
		}
		// Send back response
		$ExtRes->displayDagList($dags);
		exit;
	}
}


exit($response);
