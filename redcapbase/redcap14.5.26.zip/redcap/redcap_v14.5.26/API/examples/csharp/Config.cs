﻿namespace RedcapCSharpApiExamples
{
    public static class Config
    {
        public const string ApiSuperToken = "YOUR_SUPER_API_TOKEN";
        public const string ApiToken = "YOUR_API_TOKEN";
        public const string ApiUrl = "http://localhost/redcap/api/";
    }
}
